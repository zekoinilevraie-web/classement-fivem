@echo off
title Portail Classement Entreprises - Los Santos
echo ========================================================
echo   PORTAIL OFFICIEL DE CLASSEMENT DES ENTREPRISES
echo               LOS SANTOS EXECUTIVE
echo ========================================================
echo.
echo Verification des dependances...
if not exist "node_modules" (
    echo Installation des modules requis...
    call npm install
)

echo Demarrage du serveur sur http://localhost:3000 ...
start "" http://localhost:3000
node server.js
pause
