// Script to verify bot connection and list server roles
const db = require('../db.js');

async function check() {
  const cfg = db.getDiscordConfig();
  console.log('Testing Discord Connection with:');
  console.log('- Client ID:', cfg.clientId);
  console.log('- Guild ID:', cfg.guildId);

  try {
    const res = await fetch(`https://discord.com/api/guilds/${cfg.guildId}`, {
      headers: { Authorization: `Bot ${cfg.botToken}` }
    });
    const guild = await res.json();
    if (!res.ok) {
      console.log('❌ Discord API response:', guild);
      if (guild.code === 10004) {
        console.log('\n👉 Le bot "Bot Légal" n\'est pas encore sur le serveur Discord.');
        console.log('👉 Invitez-le avec ce lien :');
        console.log(`https://discord.com/oauth2/authorize?client_id=${cfg.clientId}&permissions=268435456&scope=bot\n`);
      }
      return;
    }

    console.log('✅ Bot connecté au serveur Discord :', guild.name);
    console.log('Nombre de membres :', guild.approximate_member_count || 'N/A');

    // Fetch roles
    const rolesRes = await fetch(`https://discord.com/api/guilds/${cfg.guildId}/roles`, {
      headers: { Authorization: `Bot ${cfg.botToken}` }
    });
    const roles = await rolesRes.json();
    console.log(`\n📋 ${roles.length} rôles détectés sur le serveur :`);
    roles.forEach(r => {
      console.log(`  - [${r.id}] ${r.name}`);
    });
  } catch (err) {
    console.error('Erreur :', err.message);
  }
}

check();
