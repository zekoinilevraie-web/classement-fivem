# 🏆 Portail de Classement & Bilans des Entreprises - Los Santos

Portail web complet et immersif conçu pour le suivi économique, le classement hebdomadaire et la valorisation des **38 entreprises** réparties dans les **5 catégories officielles**.

---

## 🚀 Démarrage Rapide

### Option 1 (Le plus simple sur Windows)
Double-cliquez sur le fichier :
👉 **`LANCER_LE_SITE.bat`**
*(Le serveur se lance et votre navigateur web s'ouvre automatiquement sur `http://localhost:3000`)*

### Option 2 (Via le terminal)
```bash
npm install
npm start
```
Puis ouvrez votre navigateur sur : **`http://localhost:3000`**

---

## 🤖 Guide Complet : Mettre en place le Bot Discord & Détection des Rôles

Le site web s'appuie sur l'API Discord officielle pour détecter automatiquement les rôles des joueurs lorsqu'ils se connectent.

### 🎯 Comment le Bot détecte-t-il les patrons ?
Dans votre serveur Discord, un chef d'entreprise a **2 rôles cumulés** :
1. Un rôle de **Statut** : `👑 Patron(e)` ou `🤝 Co-Patron(e)`.
2. Le rôle de son **Entreprise** : par exemple `👮 SASP`, `🏎️ Concess Auto`, `🔧 · 𝐋𝐒-𝐂𝐔𝐒𝐓𝐎𝐌`, `🍔 Burger Shot`, `🦄 Unicorn`, etc.

**Le processus de détection automatique :**
1. Le joueur clique sur **"Connexion Officielle via Discord (OAuth2)"** sur le site.
2. Il autorise l'accès à son compte Discord.
3. Le serveur web interroge votre bot Discord pour récupérer la liste exacte de ses rôles sur votre serveur Discord FiveM.
4. L'algorithme analyse ses rôles :
   - S'il détecte `👑 Patron(e)` + `👮 SASP` ➔ il le connecte en tant que **👑 Patron(e) SASP**.
   - Il isole sa vue : il n'a accès qu'à la catégorie **Services Publics** et à la fiche de la **SASP**.
   - Il peut directement renseigner son Chiffre d'Affaires, ses Charges et Salaires, et visualiser son **Bénéfice Net**.

---

### 📋 Tutoriel Pas-à-Pas : Comment créer et connecter votre Bot Discord

#### Étape 1 : Créer l'Application sur Discord Developer Portal
1. Rendez-vous sur le site officiel : **[https://discord.com/developers/applications](https://discord.com/developers/applications)**
2. Connectez-vous avec votre compte Discord.
3. Cliquez sur le bouton bleu en haut à droite : **"New Application"**.
4. Donnez-lui un nom (ex : `Classement Entreprises FiveM`) et acceptez les conditions.

#### Étape 2 : Récupérer le Client ID et le Client Secret
1. Dans le menu de gauche, cliquez sur **"OAuth2"** ➔ **"General"**.
2. Vous verrez **Client ID** : cliquez sur **"Copy"** et notez-le.
3. Juste en dessous, vous verrez **Client Secret** : cliquez sur **"Reset Secret"**, confirmez, puis cliquez sur **"Copy"** et notez-le.
4. Dans la section **"Redirects"**, cliquez sur **"Add Redirect"** et ajoutez exactement cette adresse :
   ```
   http://localhost:3000/api/auth/discord/callback
   ```
   *(Si vous hébergez plus tard votre site sur un serveur VPS avec un nom de domaine, remplacez `localhost:3000` par votre domaine).*
5. Cliquez sur **"Save Changes"** tout en bas.

#### Étape 3 : Configurer le Bot et activer les permissions
1. Dans le menu de gauche, cliquez sur **"Bot"**.
2. Sous le nom du bot, cliquez sur le bouton **"Reset Token"**, confirmez, puis cliquez sur **"Copy"** : c'est votre **Bot Token** (gardez-le secret !).
3. Descendez un peu plus bas jusqu'à la section **"Privileged Gateway Intents"** :
   - Activez impérativement : **"Server Members Intent"** (coché sur ON).
   - *(Cela permet au bot de lire les rôles de chaque membre du serveur).*
4. Cliquez sur **"Save Changes"**.

#### Étape 4 : Inviter le Bot sur votre serveur Discord
1. Dans le menu de gauche, cliquez sur **"OAuth2"** ➔ **"URL Generator"**.
2. Dans la boîte **Scopes**, cochez :
   - `bot`
   - `identify`
   - `guilds.members.read`
3. Dans la boîte **Bot Permissions** qui apparaît en dessous, cochez :
   - `Manage Roles` (ou au minimum `View Audit Log` / lecture des membres).
4. Copiez l'URL générée tout en bas (**Generated URL**).
5. Collez cette URL dans votre navigateur, choisissez votre serveur Discord FiveM et cliquez sur **Autoriser**.
6. Votre bot est maintenant présent sur votre Discord !

#### Étape 5 : Récupérer l'ID de votre serveur Discord (Guild ID)
1. Ouvrez votre application Discord.
2. Allez dans **Paramètres Utilisateur** (la roue crantée en bas à gauche) ➔ **Avancés** ➔ Activez le **"Mode développeur"**.
3. Faites un clic droit sur l'icône de votre serveur Discord dans la barre de gauche, et cliquez sur **"Copier l'identifiant du serveur"** : c'est votre **Guild ID**.

#### Étape 6 : Enregistrer la configuration dans le site
1. Ouvrez votre site sur **`http://localhost:3000`**.
2. En haut à droite, cliquez sur **"Panel Fondateur (Admin)"**.
3. Allez dans le 5ème onglet : **"Discord OAuth & Rôles"**.
4. Remplissez les 4 cases avec vos valeurs :
   - **Client ID Discord**
   - **Client Secret**
   - **Guild ID (ID du Serveur)**
   - **Bot Token**
5. Cliquez sur le bouton vert : **"Enregistrer la Configuration Discord"**.

C'est tout ! À partir de cet instant, n'importe quel joueur qui clique sur **"Connexion Officielle via Discord (OAuth2)"** verra ses rôles automatiquement détectés et son entreprise débloquée !

---

### ⚡ Pas envie de configurer le bot tout de suite ? (Simulateur 1-Clic)
Si vous voulez simplement tester le site ou faire une démonstration à vos joueurs immédiatement :
1. Cliquez sur **"Connexion / Changement de compte"** en haut à droite.
2. Dans le bloc violet Discord, vous avez des **pastilles 1-clic prêtes à l'emploi** :
   - `👑 Patron(e) SASP`
   - `👑 Patron(e) Concess Auto`
   - `🤝 Co-Patron(e) LS-Custom`
   - `👑 Patron(e) Burger Shot`
   - `👑 Patron(e) Unicorn`
   - `👑 Patron(e) Groupe6`
   - `🚘 Référent Automobile`
3. Cliquez sur l'une d'entre elles : le site simule la détection des deux rôles exactement comme le ferait le bot, sans aucune configuration nécessaire !

---

## 👥 Comptes & Système de Rôles Cloisonnés

Le système intègre un **cloisonnement strict par catégorie** selon vos instructions :
- **Le Fondateur** a les pleins pouvoirs (SuperAdmin) : vision globale de toutes les entreprises, attribution des distinctions / médailles, gestion des rôles des référents, ouverture de nouvelles semaines, ajout d'entreprises et export Discord RP.
- **Les Référents de Catégorie** n'ont accès **qu'à leur propre secteur**. Ils ne voient pas les autres catégories et ne peuvent déposer de bilans que pour les entreprises de leur secteur.

### Comptes pré-configurés :

| Identifiant | Mot de passe | Rôle | Catégorie assignée / Visibilité |
| :--- | :--- | :--- | :--- |
| **`fondateur`** | `admin` | **Fondateur (SuperAdmin)** | **Toutes les catégories** + Panel Admin + Décorations |
| **`ref_services`** | `pass` | Référent | **Services Publics uniquement** |
| **`ref_auto`** | `pass` | Référent | **Automobile uniquement** |
| **`ref_evenementiel`** | `pass` | Référent | **Événementiel uniquement** |
| **`ref_public_prive`** | `pass` | Référent | **Publics & Privés uniquement** |
| **`ref_alimentaire`** | `pass` | Référent | **Alimentaire uniquement** |

> 💡 **Astuce Démo Immédiate** : Sur la page de connexion, des boutons d'accès rapide en 1 clic vous permettent de basculer instantanément d'un profil à un autre.

---

## 🏢 Répertoire des 38 Entreprises Incluses

### 1. 🛡️ Services Publics (7 structures)
- Gouvernement
- FBI
- DOJ (Department of Justice)
- SASP (San Andreas State Police)
- Cabinet d'Avocats
- EMS (Emergency Medical Services)
- National Guard

### 2. 🏎️ Automobile (7 structures)
- Concession Auto
- Mosely Auto Okaz
- Flints Auto
- Phoenix Custom
- Reaper Custom
- Car Club 76
- LS Custom

### 3. 🍸 Événementiel (10 structures)
- Unicorn (Vanilla Unicorn)
- Perico Bar
- Club 97
- Label 97
- Weazel News
- Yellow Jack
- Nocturnal
- Hookah Club
- Suncheon Plaza
- Tequi-la-la

### 4. 🏢 Publics & Privés (10 structures)
- Group 6 (Gruppe 6)
- Cuve Industrie
- Taxi
- Vigneron
- LS Postal
- Tabac
- Cayo Ferraille
- Medvedev Maritime
- Securo (SecuroServ)
- Dynasty 8

### 5. 🍔 Alimentaire (7 structures)
- Casa Bellini
- Burger Shot
- Cat Café
- LTD Mirror Park
- LTD Little Seoul
- LTD Grove Street
- LTD Forum Drive

---

## ✨ Fonctionnalités Majeures

1. **Podium d'Honneur 3D Glassmorphism :**
   - Mise en avant des 3 structures en tête de la semaine (1ère Place Or 🥇, 2ème Place Argent 🥈, 3ème Place Bronze 🥉).
   - Affichage dynamique du Chiffre d'Affaires, nombre d'employés et nombre d'événements.

2. **Dépôt des Bilans de Fin de Semaine :**
   - Chiffre d'affaires de fin de semaine ($ CA).
   - Nombre d'employés actifs dans l'entreprise.
   - Nom du patron et des co-patrons.
   - **Générateur dynamique d'événements** : titre, date, type d'événement, nombre de participants estimés, description, lien de preuve/photo.
   - Remarques et faits marquants de la semaine.

3. **Distinctions & Félicitations du Fondateur :**
   - Le Fondateur peut décerner des médailles officielles (*"🏆 Entreprise de la Semaine"*, *"💎 Top Chiffre d'Affaires"*, *"⚡ Événement d'Or"*, *"🛡️ Dévouement Exemplaire"*, etc.) accompagnées d'un mot officiel de félicitations affiché directement sur la fiche de l'entreprise.

4. **Barre de Simulation Fondateur (En haut de page) :**
   - Lorsque vous êtes connecté en tant que Fondateur, une barre spéciale en haut vous permet en 1 clic de simuler la vue cloisonnée d'un référent (ex: tester ce que voit le Référent Automobile) et de revenir à la vue globale Fondateur instantanément.

5. **Panel d'Administration Fondateur :**
   - Créer de nouveaux comptes ou modifier les affectations de catégorie.
   - Ouvrir et activer de nouvelles semaines (Semaine 39, Semaine 40, etc.).
   - Ajouter de nouvelles entreprises au répertoire en cas d'ouverture en ville.
   - **Générateur d'Export Discord RP** : Un bouton permet de copier un récapitulatif complet prêt à être collé dans le salon `#annonces-entreprises` de votre Discord !
